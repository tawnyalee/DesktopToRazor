namespace MyDesktopApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.btnCreateCustomer = new System.Windows.Forms.Button();
            this.btnDoubleAge = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(12, 12);
            this.txtName.Name = "txtName";
            this.txtName.PlaceholderText = "Enter name";
            this.txtName.Size = new System.Drawing.Size(200, 23);
            this.txtName.TabIndex = 0;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(12, 41);
            this.txtAge.Name = "txtAge";
            this.txtAge.PlaceholderText = "Enter age";
            this.txtAge.Size = new System.Drawing.Size(200, 23);
            this.txtAge.TabIndex = 1;
            // 
            // btnCreateCustomer
            // 
            this.btnCreateCustomer.Location = new System.Drawing.Point(12, 70);
            this.btnCreateCustomer.Name = "btnCreateCustomer";
            this.btnCreateCustomer.Size = new System.Drawing.Size(200, 23);
            this.btnCreateCustomer.TabIndex = 2;
            this.btnCreateCustomer.Text = "Create Customer";
            this.btnCreateCustomer.UseVisualStyleBackColor = true;
            this.btnCreateCustomer.Click += new System.EventHandler(this.btnCreateCustomer_Click);
            // 
            // btnDoubleAge
            // 
            this.btnDoubleAge.Location = new System.Drawing.Point(12, 99);
            this.btnDoubleAge.Name = "btnDoubleAge";
            this.btnDoubleAge.Size = new System.Drawing.Size(200, 23);
            this.btnDoubleAge.TabIndex = 3;
            this.btnDoubleAge.Text = "Double Age";
            this.btnDoubleAge.UseVisualStyleBackColor = true;
            this.btnDoubleAge.Click += new System.EventHandler(this.btnDoubleAge_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(12, 134);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(39, 15);
            this.lblResult.TabIndex = 4;
            this.lblResult.Text = "Result";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(230, 170);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.btnDoubleAge);
            this.Controls.Add(this.btnCreateCustomer);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtName);
            this.Name = "MainForm";
            this.Text = "My Desktop App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtName;
        private TextBox txtAge;
        private Button btnCreateCustomer;
        private Button btnDoubleAge;
        private Label lblResult;
    }
}

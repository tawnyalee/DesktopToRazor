using System;
using System.Windows.Forms;
using MyDesktopApp.Logic;
using MyDesktopApp.Models;

namespace MyDesktopApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnCreateCustomer_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtAge.Text, out int age))
            {
                Customer customer = new Customer(txtName.Text, age);
                lblResult.Text = CustomerHelper.GetCustomerSummary(customer);
            }
            else
            {
                lblResult.Text = "Please enter a valid age.";
            }
        }

        private void btnDoubleAge_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtAge.Text, out int age))
            {
                int doubled = Calculator.DoubleValue(age);
                lblResult.Text = $"Doubled age: {doubled}";
            }
            else
            {
                lblResult.Text = "Please enter a valid age.";
            }
        }
    }
}

using MyDesktopApp.Models;

namespace MyDesktopApp.Logic
{
    public static class CustomerHelper
    {
        public static string GetCustomerSummary(Customer customer)
        {
            return $"Customer: {customer.Name}, Age: {customer.Age}";
        }
    }
}

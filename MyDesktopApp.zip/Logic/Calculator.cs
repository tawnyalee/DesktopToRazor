namespace MyDesktopApp.Logic
{
    public static class Calculator
    {
        public static int DoubleValue(int number) => number * 2;
    }
}
